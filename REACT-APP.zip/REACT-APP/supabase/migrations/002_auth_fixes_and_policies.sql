-- ============================================================
-- Migration 002: Auth Fixes, RLS Hardening, Storage & Triggers
-- Project: report-crime-8b06b / oxjwrmxmhuegjcvrctvp
-- ============================================================

-- ----------------------------------------------------------------
-- 1.  SAFETY: drop duplicate / conflicting policies before re-creating
-- ----------------------------------------------------------------
DO $$
DECLARE
  pol RECORD;
BEGIN
  FOR pol IN
    SELECT policyname, tablename
    FROM   pg_policies
    WHERE  schemaname = 'public'
  LOOP
    EXECUTE format('DROP POLICY IF EXISTS %I ON public.%I', pol.policyname, pol.tablename);
  END LOOP;
END $$;

-- ----------------------------------------------------------------
-- 2.  HELPER FUNCTIONS
-- ----------------------------------------------------------------

-- Returns TRUE when the calling user is in admin_users
CREATE OR REPLACE FUNCTION public.is_admin(user_uuid UUID DEFAULT auth.uid())
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
STABLE
AS $$
BEGIN
  IF user_uuid IS NULL THEN RETURN FALSE; END IF;
  RETURN EXISTS (
    SELECT 1 FROM public.admin_users WHERE user_id = user_uuid
  );
END;
$$;

-- Returns TRUE when the calling user is a super_admin
CREATE OR REPLACE FUNCTION public.is_super_admin(user_uuid UUID DEFAULT auth.uid())
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
STABLE
AS $$
BEGIN
  IF user_uuid IS NULL THEN RETURN FALSE; END IF;
  RETURN EXISTS (
    SELECT 1 FROM public.admin_users
    WHERE  user_id = user_uuid AND role = 'super_admin'
  );
END;
$$;

-- ----------------------------------------------------------------
-- 3.  ENSURE ALL TABLES EXIST (idempotent)
-- ----------------------------------------------------------------

CREATE TABLE IF NOT EXISTS public.admin_users (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id    UUID REFERENCES auth.users(id) ON DELETE CASCADE UNIQUE NOT NULL,
  email      TEXT UNIQUE NOT NULL,
  role       TEXT DEFAULT 'admin' CHECK (role IN ('admin', 'super_admin')),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.user_profiles (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id    UUID REFERENCES auth.users(id) ON DELETE CASCADE UNIQUE NOT NULL,
  username   TEXT,
  phone      TEXT,
  full_name  TEXT,
  email      TEXT,
  is_active  BOOLEAN DEFAULT TRUE,
  last_login TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.crime_reports (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  type         TEXT NOT NULL CHECK (type IN ('Crime','Complaint')),
  location     TEXT NOT NULL,
  date         DATE NOT NULL,
  description  TEXT NOT NULL,
  category     TEXT DEFAULT 'other',
  file_url     TEXT,
  status       TEXT DEFAULT 'pending' CHECK (status IN ('pending','reviewed','resolved','rejected')),
  user_id      UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  admin_notes  TEXT,
  reviewed_by  UUID,
  reviewed_at  TIMESTAMPTZ,
  created_at   TIMESTAMPTZ DEFAULT NOW(),
  updated_at   TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.missing_persons (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name               TEXT NOT NULL,
  last_seen_location TEXT NOT NULL,
  contact_info       TEXT NOT NULL,
  gender             TEXT,
  date_missing       DATE NOT NULL,
  photo_url          TEXT,
  notes              TEXT,
  status             TEXT DEFAULT 'active' CHECK (status IN ('active','found','closed')),
  user_id            UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  admin_notes        TEXT,
  reviewed_by        UUID,
  reviewed_at        TIMESTAMPTZ,
  created_at         TIMESTAMPTZ DEFAULT NOW(),
  updated_at         TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.missing_property (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  item_name          TEXT NOT NULL,
  category           TEXT DEFAULT 'other',
  last_seen_location TEXT NOT NULL,
  date_lost          DATE NOT NULL,
  description        TEXT NOT NULL,
  photo_url          TEXT,
  status             TEXT DEFAULT 'active' CHECK (status IN ('active','found','closed')),
  user_id            UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  admin_notes        TEXT,
  reviewed_by        UUID,
  reviewed_at        TIMESTAMPTZ,
  created_at         TIMESTAMPTZ DEFAULT NOW(),
  updated_at         TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.lost_found_items (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  item_name   TEXT NOT NULL,
  category    TEXT,
  location    TEXT,
  description TEXT,
  status      TEXT DEFAULT 'lost' CHECK (status IN ('lost','found','claimed')),
  user_id     UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at  TIMESTAMPTZ DEFAULT NOW(),
  updated_at  TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.notifications (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title      TEXT NOT NULL,
  message    TEXT NOT NULL,
  user_id    UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  read       BOOLEAN DEFAULT FALSE,
  type       TEXT DEFAULT 'info' CHECK (type IN ('info','warning','success','error')),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.messages (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  sender_id        UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  receiver_id      UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  related_report_id UUID,
  body             TEXT NOT NULL,
  is_from_admin    BOOLEAN DEFAULT FALSE,
  read             BOOLEAN DEFAULT FALSE,
  created_at       TIMESTAMPTZ DEFAULT NOW()
);

-- ----------------------------------------------------------------
-- 4.  ENABLE RLS ON EVERY TABLE
-- ----------------------------------------------------------------
ALTER TABLE public.admin_users      ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_profiles    ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.crime_reports    ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.missing_persons  ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.missing_property ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lost_found_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notifications    ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.messages         ENABLE ROW LEVEL SECURITY;

-- ----------------------------------------------------------------
-- 5.  RLS POLICIES
-- ----------------------------------------------------------------

-- ── admin_users ──────────────────────────────────────────────────
CREATE POLICY "admin_users: admins can select"
  ON public.admin_users FOR SELECT
  USING (public.is_admin());

CREATE POLICY "admin_users: super_admin can insert"
  ON public.admin_users FOR INSERT
  WITH CHECK (public.is_super_admin());

CREATE POLICY "admin_users: super_admin can delete"
  ON public.admin_users FOR DELETE
  USING (public.is_super_admin());

CREATE POLICY "admin_users: super_admin can update"
  ON public.admin_users FOR UPDATE
  USING (public.is_super_admin());

-- ── user_profiles ────────────────────────────────────────────────
CREATE POLICY "user_profiles: owner can select"
  ON public.user_profiles FOR SELECT
  USING (auth.uid() = user_id OR public.is_admin());

CREATE POLICY "user_profiles: owner can insert"
  ON public.user_profiles FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "user_profiles: owner can update"
  ON public.user_profiles FOR UPDATE
  USING (auth.uid() = user_id OR public.is_admin());

CREATE POLICY "user_profiles: admin can delete"
  ON public.user_profiles FOR DELETE
  USING (public.is_admin());

-- ── crime_reports ────────────────────────────────────────────────
CREATE POLICY "crime_reports: owner or admin select"
  ON public.crime_reports FOR SELECT
  USING (auth.uid() = user_id OR public.is_admin());

CREATE POLICY "crime_reports: authenticated insert"
  ON public.crime_reports FOR INSERT
  WITH CHECK (auth.uid() = user_id AND auth.role() = 'authenticated');

CREATE POLICY "crime_reports: admin update"
  ON public.crime_reports FOR UPDATE
  USING (public.is_admin());

CREATE POLICY "crime_reports: admin delete"
  ON public.crime_reports FOR DELETE
  USING (public.is_admin());

-- ── missing_persons ──────────────────────────────────────────────
CREATE POLICY "missing_persons: public select"
  ON public.missing_persons FOR SELECT
  USING (TRUE);  -- public listing so community can help

CREATE POLICY "missing_persons: authenticated insert"
  ON public.missing_persons FOR INSERT
  WITH CHECK (auth.uid() = user_id AND auth.role() = 'authenticated');

CREATE POLICY "missing_persons: admin update"
  ON public.missing_persons FOR UPDATE
  USING (public.is_admin());

CREATE POLICY "missing_persons: admin delete"
  ON public.missing_persons FOR DELETE
  USING (public.is_admin());

-- ── missing_property ─────────────────────────────────────────────
CREATE POLICY "missing_property: public select"
  ON public.missing_property FOR SELECT
  USING (TRUE);

CREATE POLICY "missing_property: authenticated insert"
  ON public.missing_property FOR INSERT
  WITH CHECK (auth.uid() = user_id AND auth.role() = 'authenticated');

CREATE POLICY "missing_property: admin update"
  ON public.missing_property FOR UPDATE
  USING (public.is_admin());

CREATE POLICY "missing_property: admin delete"
  ON public.missing_property FOR DELETE
  USING (public.is_admin());

-- ── lost_found_items ─────────────────────────────────────────────
CREATE POLICY "lost_found: public select"
  ON public.lost_found_items FOR SELECT
  USING (TRUE);

CREATE POLICY "lost_found: authenticated insert"
  ON public.lost_found_items FOR INSERT
  WITH CHECK (auth.uid() = user_id AND auth.role() = 'authenticated');

CREATE POLICY "lost_found: owner or admin update"
  ON public.lost_found_items FOR UPDATE
  USING (auth.uid() = user_id OR public.is_admin());

CREATE POLICY "lost_found: owner or admin delete"
  ON public.lost_found_items FOR DELETE
  USING (auth.uid() = user_id OR public.is_admin());

-- ── notifications ────────────────────────────────────────────────
CREATE POLICY "notifications: owner select"
  ON public.notifications FOR SELECT
  USING (auth.uid() = user_id);

-- Allow both admins AND the system (service_role) to insert notifications
CREATE POLICY "notifications: admin or service insert"
  ON public.notifications FOR INSERT
  WITH CHECK (public.is_admin() OR auth.role() = 'service_role');

CREATE POLICY "notifications: owner update (mark read)"
  ON public.notifications FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "notifications: owner delete"
  ON public.notifications FOR DELETE
  USING (auth.uid() = user_id OR public.is_admin());

-- ── messages ─────────────────────────────────────────────────────
CREATE POLICY "messages: participant select"
  ON public.messages FOR SELECT
  USING (auth.uid() = sender_id OR auth.uid() = receiver_id OR public.is_admin());

CREATE POLICY "messages: authenticated insert"
  ON public.messages FOR INSERT
  WITH CHECK (auth.uid() = sender_id AND auth.role() = 'authenticated');

CREATE POLICY "messages: receiver can mark read"
  ON public.messages FOR UPDATE
  USING (auth.uid() = receiver_id OR public.is_admin());

-- ----------------------------------------------------------------
-- 6.  STORAGE BUCKET: evidence
-- ----------------------------------------------------------------
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'evidence',
  'evidence',
  TRUE,
  52428800,  -- 50 MB
  ARRAY[
    'image/jpeg','image/png','image/webp','image/gif',
    'video/mp4','video/quicktime','video/webm',
    'audio/mpeg','audio/wav','audio/ogg',
    'application/pdf',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
  ]
)
ON CONFLICT (id) DO UPDATE SET
  public             = TRUE,
  file_size_limit    = 52428800,
  allowed_mime_types = EXCLUDED.allowed_mime_types;

-- Storage RLS: anyone authenticated can upload to their own folder
DROP POLICY IF EXISTS "evidence: authenticated upload"  ON storage.objects;
DROP POLICY IF EXISTS "evidence: public read"           ON storage.objects;
DROP POLICY IF EXISTS "evidence: owner or admin delete" ON storage.objects;

CREATE POLICY "evidence: authenticated upload"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (
    bucket_id = 'evidence'
    AND (storage.foldername(name))[2] = auth.uid()::text
  );

CREATE POLICY "evidence: public read"
  ON storage.objects FOR SELECT
  TO public
  USING (bucket_id = 'evidence');

CREATE POLICY "evidence: owner or admin delete"
  ON storage.objects FOR DELETE
  TO authenticated
  USING (
    bucket_id = 'evidence'
    AND (
      (storage.foldername(name))[2] = auth.uid()::text
      OR public.is_admin()
    )
  );

-- ----------------------------------------------------------------
-- 7.  AUTO-PROFILE TRIGGER (re-create to be safe)
-- ----------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.user_profiles (user_id, email, username, full_name, is_active)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(
      NEW.raw_user_meta_data->>'username',
      NEW.raw_user_meta_data->>'name',
      split_part(NEW.email, '@', 1)
    ),
    COALESCE(
      NEW.raw_user_meta_data->>'full_name',
      NEW.raw_user_meta_data->>'display_name',
      NEW.raw_user_meta_data->>'name',
      split_part(NEW.email, '@', 1)
    ),
    TRUE
  )
  ON CONFLICT (user_id) DO UPDATE SET
    email      = EXCLUDED.email,
    username   = COALESCE(public.user_profiles.username, EXCLUDED.username),
    full_name  = COALESCE(public.user_profiles.full_name, EXCLUDED.full_name),
    updated_at = NOW();

  -- Auto-promote the designated super-admin email
  IF NEW.email = 'jusperkato@gmail.com' THEN
    INSERT INTO public.admin_users (user_id, email, role)
    VALUES (NEW.id, NEW.email, 'super_admin')
    ON CONFLICT (user_id) DO NOTHING;
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ----------------------------------------------------------------
-- 8.  LAST-LOGIN TRIGGER
-- ----------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.handle_user_login()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Fires on SIGN_IN event: new.last_sign_in_at changes
  IF NEW.last_sign_in_at IS DISTINCT FROM OLD.last_sign_in_at THEN
    UPDATE public.user_profiles
    SET last_login = NEW.last_sign_in_at,
        updated_at = NOW()
    WHERE user_id = NEW.id;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_login ON auth.users;
CREATE TRIGGER on_auth_user_login
  AFTER UPDATE ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_user_login();

-- ----------------------------------------------------------------
-- 9.  updated_at TRIGGERS for all mutable tables
-- ----------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;

DO $$
DECLARE
  tbl TEXT;
BEGIN
  FOREACH tbl IN ARRAY ARRAY[
    'admin_users','user_profiles','crime_reports',
    'missing_persons','missing_property','lost_found_items'
  ]
  LOOP
    EXECUTE format('
      DROP TRIGGER IF EXISTS trg_set_updated_at ON public.%I;
      CREATE TRIGGER trg_set_updated_at
        BEFORE UPDATE ON public.%I
        FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
    ', tbl, tbl);
  END LOOP;
END $$;

-- ----------------------------------------------------------------
-- 10. PERFORMANCE INDEXES
-- ----------------------------------------------------------------
CREATE INDEX IF NOT EXISTS idx_crime_reports_user_id      ON public.crime_reports(user_id);
CREATE INDEX IF NOT EXISTS idx_crime_reports_status       ON public.crime_reports(status);
CREATE INDEX IF NOT EXISTS idx_crime_reports_created_at   ON public.crime_reports(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_missing_persons_user_id    ON public.missing_persons(user_id);
CREATE INDEX IF NOT EXISTS idx_missing_persons_status     ON public.missing_persons(status);
CREATE INDEX IF NOT EXISTS idx_missing_property_user_id   ON public.missing_property(user_id);
CREATE INDEX IF NOT EXISTS idx_lost_found_user_id         ON public.lost_found_items(user_id);
CREATE INDEX IF NOT EXISTS idx_lost_found_status          ON public.lost_found_items(status);
CREATE INDEX IF NOT EXISTS idx_notifications_user_id      ON public.notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_notifications_read         ON public.notifications(user_id, read);
CREATE INDEX IF NOT EXISTS idx_messages_sender            ON public.messages(sender_id);
CREATE INDEX IF NOT EXISTS idx_messages_receiver          ON public.messages(receiver_id);
CREATE INDEX IF NOT EXISTS idx_admin_users_user_id        ON public.admin_users(user_id);
CREATE INDEX IF NOT EXISTS idx_user_profiles_user_id      ON public.user_profiles(user_id);
CREATE INDEX IF NOT EXISTS idx_user_profiles_email        ON public.user_profiles(email);

-- ----------------------------------------------------------------
-- 11. REALTIME: enable publication for live updates
-- ----------------------------------------------------------------
DO $$
BEGIN
  -- Create publication if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication WHERE pubname = 'supabase_realtime'
  ) THEN
    CREATE PUBLICATION supabase_realtime;
  END IF;
END $$;

-- Add tables to realtime publication (ignore errors if already added)
ALTER PUBLICATION supabase_realtime ADD TABLE public.notifications;
ALTER PUBLICATION supabase_realtime ADD TABLE public.crime_reports;
ALTER PUBLICATION supabase_realtime ADD TABLE public.missing_persons;
ALTER PUBLICATION supabase_realtime ADD TABLE public.messages;
