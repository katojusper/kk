-- ============================================================================
-- Migration: 004_reporting_and_admin_system.sql
-- Description: Comprehensive database schema for reporting and admin management
-- ============================================================================

-- ============================================================================
-- ENHANCED CRIME REPORTS TABLE
-- ============================================================================
ALTER TABLE crime_reports ADD COLUMN IF NOT EXISTS latitude NUMERIC;
ALTER TABLE crime_reports ADD COLUMN IF NOT EXISTS longitude NUMERIC;
ALTER TABLE crime_reports ADD COLUMN IF NOT EXISTS admin_notes TEXT;
ALTER TABLE crime_reports ADD COLUMN IF NOT EXISTS reviewed_by UUID REFERENCES auth.users(id);
ALTER TABLE crime_reports ADD COLUMN IF NOT EXISTS reviewed_at TIMESTAMP WITH TIME ZONE;
ALTER TABLE crime_reports ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW();

-- Add index for better query performance
CREATE INDEX IF NOT EXISTS idx_crime_reports_status ON crime_reports(status);
CREATE INDEX IF NOT EXISTS idx_crime_reports_user_id ON crime_reports(user_id);
CREATE INDEX IF NOT EXISTS idx_crime_reports_date ON crime_reports(date);
CREATE INDEX IF NOT EXISTS idx_crime_reports_created_at ON crime_reports(created_at);

-- ============================================================================
-- ENHANCED MISSING PERSONS TABLE
-- ============================================================================
ALTER TABLE missing_persons ADD COLUMN IF NOT EXISTS height TEXT;
ALTER TABLE missing_persons ADD COLUMN IF NOT EXISTS weight TEXT;
ALTER TABLE missing_persons ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'active';
ALTER TABLE missing_persons ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW();

-- Rename columns if they exist with different names
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.columns
             WHERE table_name = 'missing_persons' AND column_name = 'last_seen_location') THEN
    -- Column already exists, do nothing
  ELSIF EXISTS (SELECT 1 FROM information_schema.columns
                WHERE table_name = 'missing_persons' AND column_name = 'location') THEN
    ALTER TABLE missing_persons RENAME COLUMN location TO last_seen_location;
  ELSE
    ALTER TABLE missing_persons ADD COLUMN last_seen_location TEXT NOT NULL DEFAULT '';
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns
             WHERE table_name = 'missing_persons' AND column_name = 'last_seen_date') THEN
    -- Column already exists, do nothing
  ELSIF EXISTS (SELECT 1 FROM information_schema.columns
                WHERE table_name = 'missing_persons' AND column_name = 'date_missing') THEN
    ALTER TABLE missing_persons RENAME COLUMN date_missing TO last_seen_date;
  ELSE
    ALTER TABLE missing_persons ADD COLUMN last_seen_date DATE NOT NULL DEFAULT CURRENT_DATE;
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns
             WHERE table_name = 'missing_persons' AND column_name = 'description') THEN
    -- Column already exists, do nothing
  ELSIF EXISTS (SELECT 1 FROM information_schema.columns
                WHERE table_name = 'missing_persons' AND column_name = 'notes') THEN
    ALTER TABLE missing_persons RENAME COLUMN notes TO description;
  ELSE
    ALTER TABLE missing_persons ADD COLUMN description TEXT;
  END IF;
END $$;

-- Add age column if it doesn't exist
ALTER TABLE missing_persons ADD COLUMN IF NOT EXISTS age INTEGER;

-- Add indexes
CREATE INDEX IF NOT EXISTS idx_missing_persons_status ON missing_persons(status);
CREATE INDEX IF NOT EXISTS idx_missing_persons_user_id ON missing_persons(user_id);
CREATE INDEX IF NOT EXISTS idx_missing_persons_created_at ON missing_persons(created_at);

-- ============================================================================
-- ENHANCED MISSING PROPERTY TABLE
-- ============================================================================
ALTER TABLE missing_property ADD COLUMN IF NOT EXISTS serial_number TEXT;
ALTER TABLE missing_property ADD COLUMN IF NOT EXISTS estimated_value NUMERIC;
ALTER TABLE missing_property ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'lost';
ALTER TABLE missing_property ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW();

-- Add indexes
CREATE INDEX IF NOT EXISTS idx_missing_property_status ON missing_property(status);
CREATE INDEX IF NOT EXISTS idx_missing_property_user_id ON missing_property(user_id);
CREATE INDEX IF NOT EXISTS idx_missing_property_created_at ON missing_property(created_at);

-- ============================================================================
-- ENHANCED UPLOADS TABLE
-- ============================================================================
ALTER TABLE uploads ADD COLUMN IF NOT EXISTS user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE;
ALTER TABLE uploads ADD COLUMN IF NOT EXISTS file_urls TEXT[];
ALTER TABLE uploads ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW();

-- Add indexes
CREATE INDEX IF NOT EXISTS idx_uploads_status ON uploads(status);
CREATE INDEX IF NOT EXISTS idx_uploads_user_id ON uploads(user_id);
CREATE INDEX IF NOT EXISTS idx_uploads_created_at ON uploads(created_at);

-- ============================================================================
-- ADMIN USERS TABLE
-- ============================================================================
CREATE TABLE IF NOT EXISTS admin_users (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT UNIQUE NOT NULL,
  username TEXT,
  role TEXT DEFAULT 'admin' CHECK (role IN ('super_admin', 'admin', 'moderator', 'viewer')),
  permissions TEXT[] DEFAULT ARRAY['view_reports', 'manage_reports'],
  is_active BOOLEAN DEFAULT TRUE,
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Add indexes
CREATE INDEX IF NOT EXISTS idx_admin_users_user_id ON admin_users(user_id);
CREATE INDEX IF NOT EXISTS idx_admin_users_email ON admin_users(email);
CREATE INDEX IF NOT EXISTS idx_admin_users_role ON admin_users(role);
CREATE INDEX IF NOT EXISTS idx_admin_users_is_active ON admin_users(is_active);

-- Enable RLS
ALTER TABLE admin_users ENABLE ROW LEVEL SECURITY;

-- Admin policies
DROP POLICY IF EXISTS "Admins can view all admin users" ON admin_users;
CREATE POLICY "Admins can view all admin users" ON admin_users
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM admin_users
      WHERE user_id = auth.uid() AND is_active = true
    )
  );

DROP POLICY IF EXISTS "Super admins can manage admin users" ON admin_users;
CREATE POLICY "Super admins can manage admin users" ON admin_users
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM admin_users
      WHERE user_id = auth.uid() AND role = 'super_admin' AND is_active = true
    )
  );

-- ============================================================================
-- ADMIN ACTIVITY LOGS TABLE
-- ============================================================================
CREATE TABLE IF NOT EXISTS admin_activity_logs (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  admin_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  action TEXT NOT NULL,
  target_id UUID,
  details TEXT,
  ip_address INET,
  user_agent TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Add indexes
CREATE INDEX IF NOT EXISTS idx_admin_activity_logs_admin_id ON admin_activity_logs(admin_id);
CREATE INDEX IF NOT EXISTS idx_admin_activity_logs_action ON admin_activity_logs(action);
CREATE INDEX IF NOT EXISTS idx_admin_activity_logs_created_at ON admin_activity_logs(created_at);

-- Enable RLS
ALTER TABLE admin_activity_logs ENABLE ROW LEVEL SECURITY;

-- Activity logs policies
DROP POLICY IF EXISTS "Admins can view activity logs" ON admin_activity_logs;
CREATE POLICY "Admins can view activity logs" ON admin_activity_logs
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM admin_users
      WHERE user_id = auth.uid() AND is_active = true
    )
  );

DROP POLICY IF EXISTS "System can insert activity logs" ON admin_activity_logs;
CREATE POLICY "System can insert activity logs" ON admin_activity_logs
  FOR INSERT WITH CHECK (true);

-- ============================================================================
-- SYSTEM SETTINGS TABLE
-- ============================================================================
CREATE TABLE IF NOT EXISTS system_settings (
  id INTEGER PRIMARY KEY DEFAULT 1,
  maintenance_mode BOOLEAN DEFAULT FALSE,
  allow_registrations BOOLEAN DEFAULT TRUE,
  require_email_verification BOOLEAN DEFAULT TRUE,
  max_reports_per_user INTEGER DEFAULT 100,
  auto_archive_days INTEGER DEFAULT 365,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_by UUID REFERENCES auth.users(id)
);

-- Ensure only one row exists
ALTER TABLE system_settings ADD CONSTRAINT single_row_constraint CHECK (id = 1);

-- Insert default settings if not exists
INSERT INTO system_settings (id, maintenance_mode, allow_registrations, require_email_verification, max_reports_per_user, auto_archive_days)
VALUES (1, FALSE, TRUE, TRUE, 100, 365)
ON CONFLICT (id) DO NOTHING;

-- Enable RLS
ALTER TABLE system_settings ENABLE ROW LEVEL SECURITY;

-- System settings policies
DROP POLICY IF EXISTS "Anyone can view system settings" ON system_settings;
CREATE POLICY "Anyone can view system settings" ON system_settings
  FOR SELECT USING (true);

DROP POLICY IF EXISTS "Super admins can update system settings" ON system_settings;
CREATE POLICY "Super admins can update system settings" ON system_settings
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM admin_users
      WHERE user_id = auth.uid() AND role = 'super_admin' AND is_active = true
    )
  );

-- ============================================================================
-- ENHANCED NOTIFICATIONS TABLE
-- ============================================================================
ALTER TABLE notifications ADD COLUMN IF NOT EXISTS type TEXT DEFAULT 'info';
ALTER TABLE notifications ADD COLUMN IF NOT EXISTS reference_id UUID;

-- Add indexes
CREATE INDEX IF NOT EXISTS idx_notifications_user_id ON notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_notifications_read ON notifications(read);
CREATE INDEX IF NOT EXISTS idx_notifications_created_at ON notifications(created_at);

-- ============================================================================
-- UPDATE RLS POLICIES FOR ENHANCED REPORTING
-- ============================================================================

-- Crime Reports - Allow admins to view all reports
DROP POLICY IF EXISTS "Admins can view all crime reports" ON crime_reports;
CREATE POLICY "Admins can view all crime reports" ON crime_reports
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM admin_users
      WHERE user_id = auth.uid() AND is_active = true
    )
  );

-- Crime Reports - Allow admins to update reports
DROP POLICY IF EXISTS "Admins can update crime reports" ON crime_reports;
CREATE POLICY "Admins can update crime reports" ON crime_reports
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM admin_users
      WHERE user_id = auth.uid() AND is_active = true
    )
  );

-- Crime Reports - Allow admins to delete reports
DROP POLICY IF EXISTS "Admins can delete crime reports" ON crime_reports;
CREATE POLICY "Admins can delete crime reports" ON crime_reports
  FOR DELETE USING (
    EXISTS (
      SELECT 1 FROM admin_users
      WHERE user_id = auth.uid() AND role IN ('super_admin', 'admin') AND is_active = true
    )
  );

-- Users can update their own reports
DROP POLICY IF EXISTS "Users can update own crime reports" ON crime_reports;
CREATE POLICY "Users can update own crime reports" ON crime_reports
  FOR UPDATE USING (auth.uid() = user_id);

-- Missing Persons - Similar policies
DROP POLICY IF EXISTS "Admins can view all missing persons" ON missing_persons;
CREATE POLICY "Admins can view all missing persons" ON missing_persons
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM admin_users
      WHERE user_id = auth.uid() AND is_active = true
    )
  );

DROP POLICY IF EXISTS "Admins can update missing persons" ON missing_persons;
CREATE POLICY "Admins can update missing persons" ON missing_persons
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM admin_users
      WHERE user_id = auth.uid() AND is_active = true
    )
  );

DROP POLICY IF EXISTS "Users can update own missing persons" ON missing_persons;
CREATE POLICY "Users can update own missing persons" ON missing_persons
  FOR UPDATE USING (auth.uid() = user_id);

-- Missing Property - Similar policies
DROP POLICY IF EXISTS "Admins can view all missing property" ON missing_property;
CREATE POLICY "Admins can view all missing property" ON missing_property
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM admin_users
      WHERE user_id = auth.uid() AND is_active = true
    )
  );

DROP POLICY IF EXISTS "Admins can update missing property" ON missing_property;
CREATE POLICY "Admins can update missing property" ON missing_property
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM admin_users
      WHERE user_id = auth.uid() AND is_active = true
    )
  );

DROP POLICY IF EXISTS "Users can update own missing property" ON missing_property;
CREATE POLICY "Users can update own missing property" ON missing_property
  FOR UPDATE USING (auth.uid() = user_id);

-- Uploads - Admin policies
DROP POLICY IF EXISTS "Admins can view all uploads" ON uploads;
CREATE POLICY "Admins can view all uploads" ON uploads
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM admin_users
      WHERE user_id = auth.uid() AND is_active = true
    )
  );

DROP POLICY IF EXISTS "Admins can update uploads" ON uploads;
CREATE POLICY "Admins can update uploads" ON uploads
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM admin_users
      WHERE user_id = auth.uid() AND is_active = true
    )
  );

DROP POLICY IF EXISTS "Users can view own uploads" ON uploads;
CREATE POLICY "Users can view own uploads" ON uploads
  FOR SELECT USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users can insert own uploads" ON uploads;
CREATE POLICY "Users can insert own uploads" ON uploads
  FOR INSERT WITH CHECK (auth.uid() = user_id);

-- ============================================================================
-- FUNCTIONS AND TRIGGERS
-- ============================================================================

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Add triggers for updated_at columns
DROP TRIGGER IF EXISTS update_crime_reports_updated_at ON crime_reports;
CREATE TRIGGER update_crime_reports_updated_at
  BEFORE UPDATE ON crime_reports
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_missing_persons_updated_at ON missing_persons;
CREATE TRIGGER update_missing_persons_updated_at
  BEFORE UPDATE ON missing_persons
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_missing_property_updated_at ON missing_property;
CREATE TRIGGER update_missing_property_updated_at
  BEFORE UPDATE ON missing_property
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_uploads_updated_at ON uploads;
CREATE TRIGGER update_uploads_updated_at
  BEFORE UPDATE ON uploads
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_admin_users_updated_at ON admin_users;
CREATE TRIGGER update_admin_users_updated_at
  BEFORE UPDATE ON admin_users
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_system_settings_updated_at ON system_settings;
CREATE TRIGGER update_system_settings_updated_at
  BEFORE UPDATE ON system_settings
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- ============================================================================
-- CREATE DEFAULT SUPER ADMIN
-- ============================================================================

-- Insert a default super admin (if email exists in user_profiles)
-- You should update this with your actual admin email
INSERT INTO admin_users (user_id, email, username, role, permissions, is_active)
SELECT
  user_id,
  email,
  COALESCE(username, email),
  'super_admin',
  ARRAY[
    'view_reports', 'manage_reports', 'delete_reports',
    'view_users', 'manage_users', 'delete_users',
    'view_admins', 'manage_admins', 'delete_admins',
    'send_broadcasts', 'manage_settings', 'view_analytics', 'export_data'
  ],
  true
FROM user_profiles
WHERE email = 'jusperkato@gmail.com'
ON CONFLICT (email) DO NOTHING;

-- ============================================================================
-- HELPFUL VIEWS FOR REPORTING
-- ============================================================================

-- View for report statistics
CREATE OR REPLACE VIEW report_statistics AS
SELECT
  'crime_reports' AS report_type,
  COUNT(*) AS total_count,
  COUNT(*) FILTER (WHERE status = 'pending') AS pending_count,
  COUNT(*) FILTER (WHERE status = 'resolved') AS resolved_count,
  COUNT(*) FILTER (WHERE status = 'rejected') AS rejected_count,
  COUNT(*) FILTER (WHERE created_at >= CURRENT_DATE - INTERVAL '30 days') AS last_30_days
FROM crime_reports
UNION ALL
SELECT
  'missing_persons' AS report_type,
  COUNT(*) AS total_count,
  COUNT(*) FILTER (WHERE status = 'active') AS pending_count,
  COUNT(*) FILTER (WHERE status = 'found') AS resolved_count,
  COUNT(*) FILTER (WHERE status = 'closed') AS rejected_count,
  COUNT(*) FILTER (WHERE created_at >= CURRENT_DATE - INTERVAL '30 days') AS last_30_days
FROM missing_persons
UNION ALL
SELECT
  'missing_property' AS report_type,
  COUNT(*) AS total_count,
  COUNT(*) FILTER (WHERE status = 'lost') AS pending_count,
  COUNT(*) FILTER (WHERE status = 'found') AS resolved_count,
  COUNT(*) FILTER (WHERE status = 'closed') AS rejected_count,
  COUNT(*) FILTER (WHERE created_at >= CURRENT_DATE - INTERVAL '30 days') AS last_30_days
FROM missing_property;

-- View for recent activity
CREATE OR REPLACE VIEW recent_activity AS
SELECT
  id,
  'crime_report' AS activity_type,
  type AS title,
  location AS description,
  status,
  user_id,
  created_at
FROM crime_reports
UNION ALL
SELECT
  id,
  'missing_person' AS activity_type,
  name AS title,
  last_seen_location AS description,
  status,
  user_id,
  created_at
FROM missing_persons
UNION ALL
SELECT
  id,
  'missing_property' AS activity_type,
  item_name AS title,
  last_seen_location AS description,
  status,
  user_id,
  created_at
FROM missing_property
ORDER BY created_at DESC;

-- ============================================================================
-- GRANT PERMISSIONS
-- ============================================================================

-- Grant necessary permissions to authenticated users
GRANT USAGE ON SCHEMA public TO authenticated;
GRANT ALL ON ALL TABLES IN SCHEMA public TO authenticated;
GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO authenticated;

-- ============================================================================
-- COMMENTS FOR DOCUMENTATION
-- ============================================================================

COMMENT ON TABLE admin_users IS 'Stores admin user information and permissions';
COMMENT ON TABLE admin_activity_logs IS 'Tracks all admin actions for audit purposes';
COMMENT ON TABLE system_settings IS 'Singleton table for system-wide settings';
COMMENT ON VIEW report_statistics IS 'Aggregated statistics for all report types';
COMMENT ON VIEW recent_activity IS 'Combined view of recent activity across all report types';

-- ============================================================================
-- END OF MIGRATION
-- ============================================================================
