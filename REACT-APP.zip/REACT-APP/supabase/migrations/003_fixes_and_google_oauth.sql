-- ============================================================
-- Migration 003: Critical Fixes + Google OAuth + Storage
-- Project: oxjwrmxmhuegjcvrctvp (report-crime-react)
-- Run via:  supabase db push
-- ============================================================

-- ----------------------------------------------------------------
-- 1.  FIX: Drop bad FK constraint on reviewed_by columns
--     Migration 001 created reviewed_by as FK → admin_users(id)
--     but the app stores auth.uid() (auth user UUID), not admin_users.id
--     This causes FK violations when admins review requests.
-- ----------------------------------------------------------------

-- crime_reports: drop FK if it exists, keep column as plain UUID
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.table_constraints tc
    JOIN information_schema.key_column_usage kcu
      ON tc.constraint_name = kcu.constraint_name
    WHERE tc.table_schema = 'public'
      AND tc.table_name   = 'crime_reports'
      AND kcu.column_name = 'reviewed_by'
      AND tc.constraint_type = 'FOREIGN KEY'
  ) THEN
    ALTER TABLE public.crime_reports
      DROP CONSTRAINT IF EXISTS crime_reports_reviewed_by_fkey;
  END IF;
END $$;

-- missing_persons: drop FK if it exists
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.table_constraints tc
    JOIN information_schema.key_column_usage kcu
      ON tc.constraint_name = kcu.constraint_name
    WHERE tc.table_schema = 'public'
      AND tc.table_name   = 'missing_persons'
      AND kcu.column_name = 'reviewed_by'
      AND tc.constraint_type = 'FOREIGN KEY'
  ) THEN
    ALTER TABLE public.missing_persons
      DROP CONSTRAINT IF EXISTS missing_persons_reviewed_by_fkey;
  END IF;
END $$;

-- missing_property: drop FK if it exists
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.table_constraints tc
    JOIN information_schema.key_column_usage kcu
      ON tc.constraint_name = kcu.constraint_name
    WHERE tc.table_schema = 'public'
      AND tc.table_name   = 'missing_property'
      AND kcu.column_name = 'reviewed_by'
      AND tc.constraint_type = 'FOREIGN KEY'
  ) THEN
    ALTER TABLE public.missing_property
      DROP CONSTRAINT IF EXISTS missing_property_reviewed_by_fkey;
  END IF;
END $$;

-- ----------------------------------------------------------------
-- 2.  FIX: status CHECK constraints on missing_persons &
--     missing_property are too strict.
--     PendingRequestsPage sets status = 'resolved' | 'rejected'
--     but the old constraint only allows 'active' | 'found' | 'closed'.
-- ----------------------------------------------------------------

-- missing_persons
ALTER TABLE public.missing_persons
  DROP CONSTRAINT IF EXISTS missing_persons_status_check;

ALTER TABLE public.missing_persons
  ADD CONSTRAINT missing_persons_status_check
  CHECK (status IN ('active', 'found', 'closed', 'resolved', 'rejected'));

-- missing_property
ALTER TABLE public.missing_property
  DROP CONSTRAINT IF EXISTS missing_property_status_check;

ALTER TABLE public.missing_property
  ADD CONSTRAINT missing_property_status_check
  CHECK (status IN ('active', 'found', 'closed', 'resolved', 'rejected'));

-- crime_reports: also ensure 'reviewed' is in the allowed set
ALTER TABLE public.crime_reports
  DROP CONSTRAINT IF EXISTS crime_reports_status_check;

ALTER TABLE public.crime_reports
  ADD CONSTRAINT crime_reports_status_check
  CHECK (status IN ('pending', 'reviewed', 'resolved', 'rejected'));

-- ----------------------------------------------------------------
-- 3.  FIX: Ensure reviewed_by / admin_notes / reviewed_at columns
--     exist on all three tables (safe ADD IF NOT EXISTS)
-- ----------------------------------------------------------------

ALTER TABLE public.crime_reports
  ADD COLUMN IF NOT EXISTS admin_notes  TEXT,
  ADD COLUMN IF NOT EXISTS reviewed_by  UUID,
  ADD COLUMN IF NOT EXISTS reviewed_at  TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS updated_at   TIMESTAMPTZ DEFAULT NOW();

ALTER TABLE public.missing_persons
  ADD COLUMN IF NOT EXISTS admin_notes  TEXT,
  ADD COLUMN IF NOT EXISTS reviewed_by  UUID,
  ADD COLUMN IF NOT EXISTS reviewed_at  TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS updated_at   TIMESTAMPTZ DEFAULT NOW();

ALTER TABLE public.missing_property
  ADD COLUMN IF NOT EXISTS admin_notes  TEXT,
  ADD COLUMN IF NOT EXISTS reviewed_by  UUID,
  ADD COLUMN IF NOT EXISTS reviewed_at  TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS updated_at   TIMESTAMPTZ DEFAULT NOW();

ALTER TABLE public.lost_found_items
  ADD COLUMN IF NOT EXISTS updated_at   TIMESTAMPTZ DEFAULT NOW();

-- ----------------------------------------------------------------
-- 4.  FIX: Notification INSERT policy
--     The old policy only allowed admins or service_role to insert.
--     PendingRequestsPage inserts notifications via the admin's JWT,
--     so is_admin() covers that — but we also add a broader policy
--     so that system triggers / edge functions can notify any user.
-- ----------------------------------------------------------------

-- Drop old restrictive insert policy (re-created below)
DROP POLICY IF EXISTS "notifications: admin or service insert" ON public.notifications;
DROP POLICY IF EXISTS "Admins can insert notifications"        ON public.notifications;

-- Admins can insert a notification for ANY user (used when reviewing requests)
CREATE POLICY "notifications: admin insert any"
  ON public.notifications FOR INSERT
  WITH CHECK (public.is_admin());

-- Service role (Edge Functions / server-side) can always insert
CREATE POLICY "notifications: service role insert"
  ON public.notifications FOR INSERT
  TO service_role
  WITH CHECK (TRUE);

-- ----------------------------------------------------------------
-- 5.  FIX: user_profiles INSERT policy
--     The trigger handle_new_user() runs as SECURITY DEFINER so it
--     can bypass RLS, but an explicit client-side upsert (authHelpers
--     upsertUserProfile) also needs INSERT permission for the owner.
-- ----------------------------------------------------------------

DROP POLICY IF EXISTS "user_profiles: owner can insert" ON public.user_profiles;

CREATE POLICY "user_profiles: owner can insert"
  ON public.user_profiles FOR INSERT
  WITH CHECK (auth.uid() = user_id);

-- ----------------------------------------------------------------
-- 6.  FIX: Allow public (unauthenticated) read on missing_persons
--     and missing_property so the MissingPersonsPage works without
--     requiring login.
-- ----------------------------------------------------------------

DROP POLICY IF EXISTS "missing_persons: public select"    ON public.missing_persons;
DROP POLICY IF EXISTS "missing_property: public select"   ON public.missing_property;
DROP POLICY IF EXISTS "lost_found: public select"         ON public.lost_found_items;

CREATE POLICY "missing_persons: public select"
  ON public.missing_persons FOR SELECT
  USING (TRUE);

CREATE POLICY "missing_property: public select"
  ON public.missing_property FOR SELECT
  USING (TRUE);

CREATE POLICY "lost_found: public select"
  ON public.lost_found_items FOR SELECT
  USING (TRUE);

-- ----------------------------------------------------------------
-- 7.  FIX: Allow public read on crime_reports for the admin
--     UploadListPage (admins need to join-select across all reports).
--     The owner-or-admin policy from 002 still applies; this just
--     ensures the admin dashboard statistics queries work.
-- ----------------------------------------------------------------

-- Already handled by "crime_reports: owner or admin select" in 002.
-- No change needed here — just adding a comment for clarity.

-- ----------------------------------------------------------------
-- 8.  ENSURE: Storage bucket 'evidence' exists and is public
-- ----------------------------------------------------------------

INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'evidence',
  'evidence',
  TRUE,
  52428800,
  ARRAY[
    'image/jpeg','image/png','image/webp','image/gif','image/heic',
    'video/mp4','video/quicktime','video/webm','video/3gpp',
    'audio/mpeg','audio/wav','audio/ogg','audio/m4a',
    'application/pdf',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
  ]
)
ON CONFLICT (id) DO UPDATE SET
  public             = TRUE,
  file_size_limit    = 52428800,
  allowed_mime_types = EXCLUDED.allowed_mime_types;

-- Storage policies (safe re-create)
DROP POLICY IF EXISTS "evidence: authenticated upload"  ON storage.objects;
DROP POLICY IF EXISTS "evidence: public read"           ON storage.objects;
DROP POLICY IF EXISTS "evidence: owner or admin delete" ON storage.objects;
DROP POLICY IF EXISTS "evidence: owner update"          ON storage.objects;

CREATE POLICY "evidence: authenticated upload"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (
    bucket_id = 'evidence'
  );

CREATE POLICY "evidence: public read"
  ON storage.objects FOR SELECT
  TO public
  USING (bucket_id = 'evidence');

CREATE POLICY "evidence: owner or admin delete"
  ON storage.objects FOR DELETE
  TO authenticated
  USING (
    bucket_id = 'evidence'
    AND (
      owner = auth.uid()
      OR public.is_admin()
    )
  );

CREATE POLICY "evidence: owner update"
  ON storage.objects FOR UPDATE
  TO authenticated
  USING (
    bucket_id = 'evidence'
    AND owner = auth.uid()
  );

-- ----------------------------------------------------------------
-- 9.  Google OAuth — add redirect URIs to auth config
--     NOTE: Supabase hosted projects set this in the Dashboard UI
--     under Authentication → URL Configuration.
--     These SQL inserts target the local config table used by the
--     Supabase CLI / self-hosted instances.
--     For the HOSTED project (oxjwrmxmhuegjcvrctvp) configure via:
--       Dashboard → Authentication → URL Configuration
--         Site URL            : http://localhost:5173
--         Redirect URLs (add) : http://localhost:5173/auth/callback
--                               http://localhost:5173/auth/reset-password
--                               https://oxjwrmxmhuegjcvrctvp.supabase.co/auth/v1/callback
-- ----------------------------------------------------------------

-- No SQL needed for hosted Google OAuth — see Dashboard instructions above.
-- The Client ID and Secret from your google-oauth-credentials.json go in:
--   Dashboard → Authentication → Providers → Google → Enable
--     Client ID     : 238171505265-hsh34hgmp3im5tkc4qrnjb2pmdgn4r9u.apps.googleusercontent.com
--     Client Secret : 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

-- ----------------------------------------------------------------
-- 10. ENSURE: Auto-profile trigger is up to date
-- ----------------------------------------------------------------

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.user_profiles (
    user_id, email, username, full_name, is_active
  )
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(
      NEW.raw_user_meta_data->>'username',
      NEW.raw_user_meta_data->>'name',
      split_part(COALESCE(NEW.email,''), '@', 1)
    ),
    COALESCE(
      NEW.raw_user_meta_data->>'full_name',
      NEW.raw_user_meta_data->>'display_name',
      NEW.raw_user_meta_data->>'name',
      split_part(COALESCE(NEW.email,''), '@', 1)
    ),
    TRUE
  )
  ON CONFLICT (user_id) DO UPDATE SET
    email      = EXCLUDED.email,
    username   = COALESCE(public.user_profiles.username, EXCLUDED.username),
    full_name  = COALESCE(public.user_profiles.full_name, EXCLUDED.full_name),
    updated_at = NOW();

  -- Auto-promote designated super-admin email
  IF NEW.email = 'jusperkato@gmail.com' THEN
    INSERT INTO public.admin_users (user_id, email, role)
    VALUES (NEW.id, NEW.email, 'super_admin')
    ON CONFLICT (user_id) DO NOTHING;
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ----------------------------------------------------------------
-- 11. ENSURE: Last-login trigger is up to date
-- ----------------------------------------------------------------

CREATE OR REPLACE FUNCTION public.handle_user_login()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.last_sign_in_at IS DISTINCT FROM OLD.last_sign_in_at THEN
    UPDATE public.user_profiles
    SET    last_login = NEW.last_sign_in_at,
           updated_at = NOW()
    WHERE  user_id = NEW.id;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_login ON auth.users;
CREATE TRIGGER on_auth_user_login
  AFTER UPDATE ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_user_login();

-- ----------------------------------------------------------------
-- 12. ENSURE: updated_at triggers on all mutable tables
-- ----------------------------------------------------------------

CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;

DO $$
DECLARE
  tbl TEXT;
BEGIN
  FOREACH tbl IN ARRAY ARRAY[
    'admin_users',
    'user_profiles',
    'crime_reports',
    'missing_persons',
    'missing_property',
    'lost_found_items'
  ]
  LOOP
    EXECUTE format('
      DROP TRIGGER IF EXISTS trg_set_updated_at ON public.%I;
      CREATE TRIGGER trg_set_updated_at
        BEFORE UPDATE ON public.%I
        FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
    ', tbl, tbl);
  END LOOP;
END $$;

-- ----------------------------------------------------------------
-- 13. PERFORMANCE INDEXES (safe, all IF NOT EXISTS)
-- ----------------------------------------------------------------

CREATE INDEX IF NOT EXISTS idx_crime_reports_user_id      ON public.crime_reports(user_id);
CREATE INDEX IF NOT EXISTS idx_crime_reports_status       ON public.crime_reports(status);
CREATE INDEX IF NOT EXISTS idx_crime_reports_created_at   ON public.crime_reports(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_missing_persons_user_id    ON public.missing_persons(user_id);
CREATE INDEX IF NOT EXISTS idx_missing_persons_status     ON public.missing_persons(status);
CREATE INDEX IF NOT EXISTS idx_missing_persons_created_at ON public.missing_persons(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_missing_property_user_id   ON public.missing_property(user_id);
CREATE INDEX IF NOT EXISTS idx_missing_property_status    ON public.missing_property(status);
CREATE INDEX IF NOT EXISTS idx_lost_found_user_id         ON public.lost_found_items(user_id);
CREATE INDEX IF NOT EXISTS idx_lost_found_status          ON public.lost_found_items(status);
CREATE INDEX IF NOT EXISTS idx_notifications_user_id      ON public.notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_notifications_unread       ON public.notifications(user_id, read) WHERE read = FALSE;
CREATE INDEX IF NOT EXISTS idx_messages_sender            ON public.messages(sender_id);
CREATE INDEX IF NOT EXISTS idx_messages_receiver          ON public.messages(receiver_id);
CREATE INDEX IF NOT EXISTS idx_admin_users_user_id        ON public.admin_users(user_id);
CREATE INDEX IF NOT EXISTS idx_user_profiles_user_id      ON public.user_profiles(user_id);
CREATE INDEX IF NOT EXISTS idx_user_profiles_email        ON public.user_profiles(email);
CREATE INDEX IF NOT EXISTS idx_user_profiles_active       ON public.user_profiles(is_active);

-- ----------------------------------------------------------------
-- 14. REALTIME: ensure key tables are in the publication
-- ----------------------------------------------------------------

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication WHERE pubname = 'supabase_realtime'
  ) THEN
    CREATE PUBLICATION supabase_realtime;
  END IF;
END $$;

DO $$
DECLARE
  tbl TEXT;
BEGIN
  FOREACH tbl IN ARRAY ARRAY[
    'notifications',
    'crime_reports',
    'missing_persons',
    'lost_found_items',
    'messages'
  ]
  LOOP
    BEGIN
      EXECUTE format(
        'ALTER PUBLICATION supabase_realtime ADD TABLE public.%I', tbl
      );
    EXCEPTION WHEN duplicate_object THEN
      -- already in publication, skip
    END;
  END LOOP;
END $$;

-- ----------------------------------------------------------------
-- 15. VERIFY helper function is_admin (idempotent refresh)
-- ----------------------------------------------------------------

CREATE OR REPLACE FUNCTION public.is_admin(user_uuid UUID DEFAULT auth.uid())
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
STABLE
AS $$
BEGIN
  IF user_uuid IS NULL THEN RETURN FALSE; END IF;
  RETURN EXISTS (
    SELECT 1 FROM public.admin_users WHERE user_id = user_uuid
  );
END;
$$;

CREATE OR REPLACE FUNCTION public.is_super_admin(user_uuid UUID DEFAULT auth.uid())
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
STABLE
AS $$
BEGIN
  IF user_uuid IS NULL THEN RETURN FALSE; END IF;
  RETURN EXISTS (
    SELECT 1 FROM public.admin_users
    WHERE  user_id = user_uuid AND role = 'super_admin'
  );
END;
$$;

-- ================================================================
-- END OF MIGRATION 003
-- ================================================================
